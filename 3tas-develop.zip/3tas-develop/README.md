# 3TAS
Html, Javascript ve CSS kullanılarak geliştirilmiş basit bir 3 taş oyunu.
İyi eğlenceler.